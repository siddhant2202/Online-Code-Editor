#include <stdio.h>
int main(){
    
    print("hey");
    return 0;
}