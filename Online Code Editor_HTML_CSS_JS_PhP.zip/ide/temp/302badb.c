#include <stdio.h>
int main(){
    print("hey");
}