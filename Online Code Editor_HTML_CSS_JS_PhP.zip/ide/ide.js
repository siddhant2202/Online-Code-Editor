let edits;

    window.onload = function() {
    edits = ace.edit("editors"); /*to do canges in ID name editor*/
    edits.setTheme("ace/theme/monokai"); /* to set theme to our editor*/
    edits.session.setMode("ace/mode/c_cpp"); /* to set default language */
}

/* to controle language change */
function changeLanguage() {

    let language = $("#languages").val(); /*get value of language selection*/

    if(language == 'c' || language == 'cpp')edits.session.setMode("ace/mode/c_cpp"); /*Change editor as per selection*/
    else if(language == 'php')edits.session.setMode("ace/mode/php");
    else if(language == 'python')edits.session.setMode("ace/mode/python");
    else if(language == 'node')edits.session.setMode("ace/mode/javascript");
}
/* to run the program */
function executeCode() {

    $.ajax({
        url: "/ide/compiler.php",
        type: "POST",
        data: {
            language: $("#languages").val(),
            code: edits.getSession().getValue()
        },
        success: function(response) {
            $(".output").text(response)
        }
    }); /* to comunicate with compiler.php file*/
}